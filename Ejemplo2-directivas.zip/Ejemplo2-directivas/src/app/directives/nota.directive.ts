import { Directive } from '@angular/core';

@Directive({
  selector: '[appNota]'
})
export class NotaDirective {

  constructor() { }

}
