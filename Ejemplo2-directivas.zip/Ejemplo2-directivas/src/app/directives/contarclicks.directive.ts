import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarclicks]'
})
export class ContarclicksDirective {

  numeroClicks: number = 0;

  // Con HostBinding modifico las propiedades CSS
  @HostBinding('style.font-size')   // tambien funciona style.fontSize
  size: string = '';

  @HostBinding('style.opacity')
  opacidad: number = 0;

  constructor() { }

  // Quiero detectar el evento click
  @HostListener('click')
  onClick(){
    this.numeroClicks++;
    this.size = (20 + this.numeroClicks + "px");
    this.opacidad += 0.1;   // this.opacidad = this.opacidad + 0.1
  }

}
