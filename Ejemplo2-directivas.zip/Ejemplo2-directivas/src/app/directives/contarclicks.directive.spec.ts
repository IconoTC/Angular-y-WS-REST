import { ContarclicksDirective } from './contarclicks.directive';

describe('ContarclicksDirective', () => {
  it('should create an instance', () => {
    const directive = new ContarclicksDirective();
    expect(directive).toBeTruthy();
  });
});
