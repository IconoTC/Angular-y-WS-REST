import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

    texto: string = "Bienvenidos al curso de Angular";
    numero: number = 76546765.34775;
    porcentaje: number = 0.63788;

    // Coje la fecha y hora del sistema
    fecha: Date = new Date();

    // La fecha asi tambien funciona
    // fecha: Date = new Date("1/25/2023");  mes/dia/año
    // fecha: string = "1/25/2023";

    persona: any = {nombre: 'Pepito', apellido: 'Perez', edad: 38,
        telefonos: {tel1: 911234567, tel2: 616987654}};
  
}
