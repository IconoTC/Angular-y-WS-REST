export class Contacto {
    key?: string | null;
    nombre?: string | null;
    telefono?: string | null;

    /*
    constructor(nombre: string, telefono: string){
        this.nombre = nombre;
        this.telefono = telefono;
    }*/
}
