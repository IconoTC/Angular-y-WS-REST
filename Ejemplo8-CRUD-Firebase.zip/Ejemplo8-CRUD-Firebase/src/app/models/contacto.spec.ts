import { Contacto } from './contacto';

describe('Contacto', () => {
  it('should create an instance', () => {
    expect(new Contacto()).toBeTruthy();
  });
});
