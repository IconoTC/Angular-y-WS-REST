import { Component } from '@angular/core';
import { Contacto } from './models/contacto';
import { AgendaService } from './services/agenda.service';
import { map } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
    contactos?: Contacto[];

    contactoForm = new FormGroup({
      nombre: new FormControl(''),
      telefono: new FormControl('')
    });

    constructor(private agendaService: AgendaService){
        this.agendaService.getAll().snapshotChanges().pipe(
            map(cambio => cambio.map(c => (
              {key: c.payload.key, ...c.payload.val()}
            )))
        ).subscribe(datos => {
          this.contactos = datos;
        });
    }

    public get nombre(){
      return this.contactoForm.get('nombre');
    }

    public get telefono(){
      return this.contactoForm.get('telefono');
    }

    alta(){
      console.log(this.contactoForm.value);
      let contacto: Contacto = { ...this.contactoForm.value }; 
      this.agendaService.create(contacto).then(() => {
        alert("Contacto agregado correctamente");
        // limpiar el formulario
        this.contactoForm.reset();
      });
    }

}
