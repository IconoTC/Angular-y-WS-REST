import { Component } from '@angular/core';
import { Contacto } from './models/contacto';
import { AgendaService } from './services/agenda.service';
import { map } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
    contactos?: Contacto[];
    mostrar: boolean = false;
    id: string = '';

    contactoForm = new FormGroup({
      nombre: new FormControl('', Validators.minLength(3)),
      telefono: new FormControl('', 
        [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
    });

    constructor(private agendaService: AgendaService){
        this.agendaService.getAll().snapshotChanges().pipe(
            map(cambio => cambio.map(c => (
              {key: c.payload.key, ...c.payload.val()}
            )))
        ).subscribe(datos => {
          this.contactos = datos;
        });
    }

    public get nombre(){
      return this.contactoForm.get('nombre');
    }

    public get telefono(){
      return this.contactoForm.get('telefono');
    }

    modificar(contacto: any){
        this.mostrar = true;
        this.id = contacto.key;
        this.contactoForm.setValue({
          nombre: contacto.nombre,
          telefono: contacto.telefono
        })
        console.log(this.contactoForm.value);
    }

    guardarCambios(){
        this.agendaService.update(this.id, this.contactoForm.value)
        .then( () => {
          alert("El contacto ha sido modificado");
          this.mostrar = false;
          // limpiar el formulario
          this.contactoForm.reset();
        })
        .catch( (error) => {
          console.log(error);
        } );
    }

    borrar(key: any){
      this.agendaService.delete(key)
        .then( () => {
          alert("Contacto eliminado");
        })
        .catch( (error) => {
          console.log(error);
        } );
    }

    alta(){
      console.log(this.contactoForm.value);
      let contacto: Contacto = { ...this.contactoForm.value }; 
      this.agendaService.create(contacto).then(() => {
          alert("Contacto agregado correctamente");
          // limpiar el formulario
          this.contactoForm.reset();
        },
        (error: any) => {
          console.log(error);
        });
    }

}
