import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';
import { Contacto } from '../models/contacto';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

    private db = '/agenda';
    agendaRef: AngularFireList<Contacto>;
  
    constructor(private angularDB: AngularFireDatabase) {
        this.agendaRef = this.angularDB.list(this.db);
    }

    getAll(): AngularFireList<Contacto> {
        return this.agendaRef;
    }

    create(contacto: Contacto): any{
        return this.agendaRef.push(contacto);
    }

    update(key: string, value: any): Promise<void>{
        return this.agendaRef.update(key, value);
    }

    delete(key: string): Promise<void>{
        return this.agendaRef.remove(key);
    }
}
