export const environment = {
    production: true,
    firebase: {
        apiKey: "AIzaSyCqJlREG0rSTc59I9FZtU4wSza49iitSmg",
        authDomain: "anabel-angular.firebaseapp.com",
        databaseURL: "https://anabel-angular-default-rtdb.europe-west1.firebasedatabase.app/",
        projectId: "anabel-angular",
        storageBucket: "anabel-angular.appspot.com",    
        messagingSenderId: "255860274083",
        appId: "1:255860274083:web:0fa8630af5082ee3976016"
    }
};