import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent {
  
  museos: Museo[] = [];
  dataSource: any;
  nombreColumnas = ['nombre', 'abierto', 'horario', 'precio'];

  constructor(private museosService: MuseosService){
    this.museos = museosService.getAll();
    this.dataSource = new MatTableDataSource(this.museos);
  }

}
