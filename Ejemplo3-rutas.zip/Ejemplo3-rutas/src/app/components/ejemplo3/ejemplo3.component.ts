import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ejemplo3',
  templateUrl: './ejemplo3.component.html',
  styleUrls: ['./ejemplo3.component.css']
})
export class Ejemplo3Component {

  hotel: string = '';
  entrada: string = '';
  salida: string = '';
  habitaciones: number = 0;

  constructor(private ruta: ActivatedRoute){

    // Recuperar el parametro de la ruta
    // El nombre del parametro es el definido en el app.module.ts  e3/:hotel 
    console.log(this.ruta);
    this.hotel = this.ruta.snapshot.params['hotel'];

    // Recuperar los query params
    this.entrada = this.ruta.snapshot.queryParams['entrada'];
    this.salida = this.ruta.snapshot.queryParams['salida'];
    this.habitaciones = this.ruta.snapshot.queryParams['habitaciones'];
  }
}
